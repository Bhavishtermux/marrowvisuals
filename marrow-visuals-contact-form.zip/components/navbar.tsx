'use client'

import { AnimatePresence, motion } from 'framer-motion'
import { Menu, Sparkles, X } from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import { navLinks, site, whatsappLink } from '@/lib/site'

const SECTION_IDS = ['home', 'services', 'why-us', 'contact']

export function Navbar() {
  const pathname = usePathname()
  const isProjectsPage = pathname === '/projects'

  const [activeSection, setActiveSection] = useState('home')
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  // Shrink / solidify the pill after leaving the top of the page
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Scroll-spy for the in-page anchors (home page only)
  useEffect(() => {
    if (isProjectsPage) return

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0]
        if (visible) setActiveSection(visible.target.id)
      },
      { rootMargin: '-45% 0px -45% 0px', threshold: [0, 0.25, 0.5, 1] },
    )

    for (const id of SECTION_IDS) {
      const element = document.getElementById(id)
      if (element) observer.observe(element)
    }

    return () => observer.disconnect()
  }, [isProjectsPage])

  // Lock body scroll while the mobile sheet is open
  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [menuOpen])

  const isActive = (href: string) => {
    if (href === '/projects') return isProjectsPage
    if (isProjectsPage) return false
    return href === `/#${activeSection}`
  }

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1], delay: 0.1 }}
        className="fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4 sm:pt-6"
      >
        <nav
          aria-label="Main navigation"
          className={cn(
            'flex w-full max-w-3xl items-center justify-between gap-2 rounded-full px-3 py-2 transition-all duration-500',
            scrolled
              ? 'glass-strong shadow-[0_16px_50px_-18px_rgba(0,0,0,0.85)]'
              : 'glass shadow-[0_10px_40px_-24px_rgba(0,0,0,0.7)]',
          )}
        >
          <Link
            href="/#home"
            className="group flex shrink-0 items-center gap-2 rounded-full px-2 py-1 focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
          >
            <span className="relative grid size-8 place-items-center rounded-xl bg-primary/20 ring-1 ring-primary/40 transition-shadow duration-300 group-hover:shadow-[0_0_18px_2px_color-mix(in_oklab,var(--primary)_55%,transparent)]">
              <Sparkles className="size-4 text-primary" aria-hidden="true" />
            </span>
            <span className="font-display text-sm font-bold tracking-tight sm:text-base">
              Marrow<span className="text-primary">.</span>Visuals
            </span>
            <span className="sr-only">{site.name} home</span>
          </Link>

          {/* Desktop links */}
          <ul className="hidden items-center gap-1 md:flex">
            {navLinks.map((link) => {
              const active = isActive(link.href)
              return (
                <li key={link.href} className="relative">
                  <Link
                    href={link.href}
                    aria-current={active ? 'page' : undefined}
                    className={cn(
                      'relative block rounded-full px-4 py-2 text-sm font-medium transition-colors duration-300',
                      active
                        ? 'text-foreground'
                        : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    {active ? (
                      <motion.span
                        layoutId="nav-pill"
                        transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                        className="absolute inset-0 -z-10 rounded-full bg-primary/22 ring-1 ring-primary/45 shadow-[0_0_22px_-4px_color-mix(in_oklab,var(--primary)_70%,transparent)]"
                      />
                    ) : null}
                    {link.label}
                  </Link>
                </li>
              )
            })}
          </ul>

          <div className="flex items-center gap-2">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all duration-300 hover:shadow-[0_0_26px_-2px_color-mix(in_oklab,var(--primary)_85%,transparent)] focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none sm:block"
            >
              Hire Us
            </a>

            <button
              type="button"
              onClick={() => setMenuOpen((open) => !open)}
              aria-expanded={menuOpen}
              aria-controls="mobile-nav"
              aria-label={menuOpen ? 'Close menu' : 'Open menu'}
              className="grid size-9 place-items-center rounded-full text-foreground transition-colors hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none md:hidden"
            >
              {menuOpen ? (
                <X className="size-5" aria-hidden="true" />
              ) : (
                <Menu className="size-5" aria-hidden="true" />
              )}
            </button>
          </div>
        </nav>
      </motion.header>

      {/* Mobile sheet */}
      <AnimatePresence>
        {menuOpen ? (
          <motion.div
            id="mobile-nav"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-40 md:hidden"
          >
            <button
              type="button"
              aria-label="Close menu"
              onClick={() => setMenuOpen(false)}
              className="absolute inset-0 bg-background/80 backdrop-blur-xl"
            />

            <motion.ul
              initial={{ y: -16, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -16, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="glass-strong absolute inset-x-4 top-24 flex flex-col gap-1 rounded-3xl p-3"
            >
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    onClick={() => setMenuOpen(false)}
                    className={cn(
                      'block rounded-2xl px-4 py-3 text-base font-medium transition-colors',
                      isActive(link.href)
                        ? 'bg-primary/20 text-foreground ring-1 ring-primary/40'
                        : 'text-muted-foreground hover:bg-white/5 hover:text-foreground',
                    )}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
              <li className="pt-1">
                <a
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setMenuOpen(false)}
                  className="block rounded-2xl bg-primary px-4 py-3 text-center text-base font-semibold text-primary-foreground"
                >
                  Hire Us
                </a>
              </li>
            </motion.ul>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </>
  )
}

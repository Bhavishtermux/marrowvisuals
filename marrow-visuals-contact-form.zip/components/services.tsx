import { Check, Clapperboard, PenTool } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { SectionHeading } from '@/components/section-heading'
import { SpotlightCard } from '@/components/spotlight-card'
import { RevealGroup, RevealItem } from '@/components/reveal'

type Service = {
  icon: LucideIcon
  index: string
  title: string
  description: string
  deliverables: string[]
  tags: string[]
}

const services: Service[] = [
  {
    icon: PenTool,
    index: '01',
    title: 'Graphic Design',
    description:
      'Visual systems engineered for the click. We design the frame people stop on — then make sure every asset around it looks like it came from the same studio.',
    deliverables: [
      'YouTube thumbnails built for click-through',
      'Social post & carousel design systems',
      'Brand identity, logo marks & style guides',
      'Ad creatives and static campaign sets',
    ],
    tags: ['Thumbnails', 'Social Posts', 'Brand Identity'],
  },
  {
    icon: Clapperboard,
    index: '02',
    title: 'Video Editing',
    description:
      'Retention-first short-form editing. Hook in the first second, pacing that never lets go, and captions plus sound design tuned per platform.',
    deliverables: [
      'Instagram Reels & YouTube Shorts',
      'TikToks with native pacing & trends',
      'Performance ad creatives (UGC style)',
      'Captions, motion graphics & sound design',
    ],
    tags: ['Reels', 'Shorts', 'TikToks', 'Ads'],
  },
]

export function Services() {
  return (
    <section
      id="services"
      aria-labelledby="services-heading"
      className="relative mx-auto max-w-6xl scroll-mt-28 px-4 py-24 sm:px-6 lg:py-32"
    >
      <SectionHeading
        eyebrow="What We Do"
        title={
          <>
            Two disciplines.{' '}
            <span className="text-gradient">Zero compromise.</span>
          </>
        }
        description="We deliberately do not do everything. We do the two things that move social metrics the most — and we go deep on both."
      />
      <h2 id="services-heading" className="sr-only">
        Our services
      </h2>

      <RevealGroup className="mt-14 grid gap-6 lg:grid-cols-2">
        {services.map((service) => (
          <RevealItem key={service.title}>
            <SpotlightCard className="flex h-full flex-col p-7 sm:p-9">
              <div className="flex items-start justify-between gap-4">
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-primary/18 ring-1 ring-primary/35 transition-shadow duration-500 group-hover:shadow-[0_0_26px_-2px_color-mix(in_oklab,var(--primary)_70%,transparent)]">
                  <service.icon className="size-5 text-primary" aria-hidden="true" />
                </span>
                <span className="font-display text-4xl font-bold text-white/8 transition-colors duration-500 group-hover:text-primary/25">
                  {service.index}
                </span>
              </div>

              <h3 className="font-display mt-6 text-2xl font-bold tracking-tight">
                {service.title}
              </h3>

              <p className="mt-3 leading-relaxed text-pretty text-muted-foreground">
                {service.description}
              </p>

              <ul className="mt-6 flex flex-col gap-3">
                {service.deliverables.map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm">
                    <Check
                      className="mt-0.5 size-4 shrink-0 text-accent"
                      aria-hidden="true"
                    />
                    <span className="leading-relaxed text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>

              <ul className="mt-auto flex flex-wrap gap-2 pt-8">
                {service.tags.map((tag) => (
                  <li
                    key={tag}
                    className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-medium text-muted-foreground"
                  >
                    {tag}
                  </li>
                ))}
              </ul>
            </SpotlightCard>
          </RevealItem>
        ))}
      </RevealGroup>
    </section>
  )
}

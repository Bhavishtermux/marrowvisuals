import { Mail, MessageCircle, Sparkles } from 'lucide-react'
import Link from 'next/link'
import { mailtoLink, navLinks, site, whatsappLink } from '@/lib/site'

const socials = [
  { icon: MessageCircle, label: 'WhatsApp', href: whatsappLink, external: true },
  { icon: Mail, label: 'Email', href: mailtoLink, external: false },
]

export function Footer() {
  return (
    <footer className="relative border-t border-white/10">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <Link href="/#home" className="flex items-center gap-2">
              <span className="grid size-8 place-items-center rounded-xl bg-primary/20 ring-1 ring-primary/40">
                <Sparkles className="size-4 text-primary" aria-hidden="true" />
              </span>
              <span className="font-display text-base font-bold tracking-tight">
                Marrow<span className="text-primary">.</span>Visuals
              </span>
            </Link>

            <p className="mt-4 text-sm leading-relaxed text-pretty text-muted-foreground">
              {site.name} — a social media creative agency specialising in graphic design and
              short-form video editing. Built for brands that need to stop the scroll.
            </p>
          </div>

          <nav aria-label="Footer navigation">
            <h2 className="text-xs font-semibold tracking-[0.16em] text-foreground uppercase">
              Navigate
            </h2>
            <ul className="mt-4 flex flex-col gap-3">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="text-xs font-semibold tracking-[0.16em] text-foreground uppercase">
              Get in touch
            </h2>
            <ul className="mt-4 flex flex-col gap-3">
              <li>
                <a
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  {site.whatsappDisplay}
                </a>
              </li>
              <li>
                <a
                  href={mailtoLink}
                  className="text-sm break-all text-muted-foreground transition-colors hover:text-foreground"
                >
                  {site.email}
                </a>
              </li>
            </ul>

            <ul className="mt-6 flex items-center gap-2">
              {socials.map((social) => (
                <li key={social.label}>
                  <a
                    href={social.href}
                    {...(social.external
                      ? { target: '_blank', rel: 'noopener noreferrer' }
                      : {})}
                    className="glass grid size-10 place-items-center rounded-xl text-muted-foreground transition-all duration-300 hover:border-primary/50 hover:text-primary hover:shadow-[0_0_20px_-4px_color-mix(in_oklab,var(--primary)_70%,transparent)] focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
                  >
                    <social.icon className="size-4" aria-hidden="true" />
                    <span className="sr-only">{social.label}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-white/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-muted-foreground">
            &copy; {new Date().getFullYear()} {site.name}. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Graphic Design &amp; Short-Form Video Editing — worldwide.
          </p>
        </div>
      </div>
    </footer>
  )
}

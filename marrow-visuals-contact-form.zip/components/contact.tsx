'use client'

import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Loader2,
  Mail,
  MessageCircle,
  Send,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { useActionState } from 'react'
import { submitContact } from '@/app/actions/contact'
import { initialContactState } from '@/lib/contact-state'
import { SectionHeading } from '@/components/section-heading'
import { SpotlightCard } from '@/components/spotlight-card'
import { Reveal } from '@/components/reveal'
import { mailtoLink, site, whatsappLink } from '@/lib/site'
import { cn } from '@/lib/utils'

const fieldClass =
  'w-full rounded-2xl border border-white/12 bg-white/[0.04] px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 transition-all duration-300 focus:border-primary/50 focus:bg-white/[0.07] focus:ring-2 focus:ring-primary/50 focus:outline-none'

type Channel = {
  icon: LucideIcon
  label: string
  value: string
  href: string
  hint: string
  external: boolean
}

const channels: Channel[] = [
  {
    icon: MessageCircle,
    label: 'WhatsApp',
    value: site.whatsappDisplay,
    href: whatsappLink,
    hint: 'Fastest reply — usually under an hour',
    external: true,
  },
  {
    icon: Mail,
    label: 'Email',
    value: site.email,
    href: mailtoLink,
    hint: 'Best for detailed briefs & attachments',
    external: false,
  },
]

export function Contact() {
  const [state, formAction, pending] = useActionState(submitContact, initialContactState)

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="relative mx-auto max-w-6xl scroll-mt-28 px-4 py-24 sm:px-6 lg:py-32"
    >
      <SectionHeading
        eyebrow="Contact"
        title={
          <>
            Let&apos;s make something{' '}
            <span className="text-gradient">worth watching.</span>
          </>
        }
        description="Send a brief or just say hi. Tell us the platform, the volume and the vibe — we'll come back with a plan and a quote."
      />
      <h2 id="contact-heading" className="sr-only">
        Contact us
      </h2>

      <div className="mt-14 grid gap-6 lg:grid-cols-[1fr_1.15fr]">
        {/* ---------------- Direct channels ---------------- */}
        <div className="flex flex-col gap-4">
          {channels.map((channel, index) => (
            <Reveal key={channel.label} delay={index * 0.08} direction="right">
              <motion.a
                href={channel.href}
                {...(channel.external
                  ? { target: '_blank', rel: 'noopener noreferrer' }
                  : {})}
                whileHover={{ x: 6 }}
                transition={{ type: 'spring', stiffness: 320, damping: 24 }}
                className="group glass flex items-center gap-4 rounded-3xl p-5 transition-colors duration-300 hover:border-primary/45 hover:bg-white/[0.07] focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
              >
                <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-primary/18 ring-1 ring-primary/35 transition-shadow duration-300 group-hover:shadow-[0_0_24px_-2px_color-mix(in_oklab,var(--primary)_70%,transparent)]">
                  <channel.icon className="size-5 text-primary" aria-hidden="true" />
                </span>

                <span className="min-w-0 flex-1">
                  <span className="block text-xs tracking-[0.16em] text-muted-foreground uppercase">
                    {channel.label}
                  </span>
                  <span className="mt-0.5 block truncate text-sm font-semibold text-foreground">
                    {channel.value}
                  </span>
                  <span className="mt-1 block text-xs text-muted-foreground">
                    {channel.hint}
                  </span>
                </span>

                <ArrowRight
                  className="size-4 shrink-0 text-muted-foreground transition-all duration-300 group-hover:translate-x-1 group-hover:text-primary"
                  aria-hidden="true"
                />
                {channel.external ? <span className="sr-only">(opens in a new tab)</span> : null}
              </motion.a>
            </Reveal>
          ))}

          <Reveal delay={0.16} direction="right">
            <SpotlightCard className="p-6" lift={false}>
              <div className="flex items-center gap-3">
                <Clock className="size-4 text-accent" aria-hidden="true" />
                <p className="text-sm font-semibold">Working hours</p>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Mon – Sat, 10:00 – 20:00 IST. Rush and weekend delivery available on
                retainer — just flag it in your message.
              </p>
              <div className="mt-5 flex items-center gap-2 border-t border-white/10 pt-5">
                <span className="relative flex size-2">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-accent opacity-75" />
                  <span className="relative inline-flex size-2 rounded-full bg-accent" />
                </span>
                <p className="text-xs font-medium text-muted-foreground">
                  Currently taking on new projects
                </p>
              </div>
            </SpotlightCard>
          </Reveal>
        </div>

        {/* ---------------- Form ---------------- */}
        <Reveal delay={0.1} direction="left">
          <SpotlightCard className="p-7 sm:p-9" lift={false}>
            <AnimatePresence mode="wait">
              {state.status === 'success' ? (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                  className="flex min-h-[26rem] flex-col items-center justify-center text-center"
                >
                  <span className="grid size-16 place-items-center rounded-full bg-accent/15 ring-1 ring-accent/40">
                    <CheckCircle2 className="size-7 text-accent" aria-hidden="true" />
                  </span>
                  <h3 className="font-display mt-6 text-2xl font-bold">Brief received</h3>
                  <p
                    role="status"
                    className="mt-3 max-w-sm leading-relaxed text-pretty text-muted-foreground"
                  >
                    {state.message}
                  </p>
                  <a
                    href={whatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-shadow hover:shadow-[0_0_30px_-2px_color-mix(in_oklab,var(--primary)_85%,transparent)]"
                  >
                    <MessageCircle className="size-4" aria-hidden="true" />
                    Chat now instead
                  </a>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  action={formAction}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col gap-5"
                  noValidate
                >
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="flex flex-col gap-2">
                      <label htmlFor="name" className="text-sm font-medium">
                        Your name
                      </label>
                      <input
                        id="name"
                        name="name"
                        type="text"
                        required
                        autoComplete="name"
                        placeholder="Alex Mercer"
                        aria-invalid={Boolean(state.errors?.name)}
                        aria-describedby={state.errors?.name ? 'name-error' : undefined}
                        className={cn(fieldClass, state.errors?.name && 'border-destructive/60')}
                      />
                      {state.errors?.name ? (
                        <p id="name-error" className="text-xs text-destructive">
                          {state.errors.name}
                        </p>
                      ) : null}
                    </div>

                    <div className="flex flex-col gap-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email
                      </label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        required
                        autoComplete="email"
                        placeholder="you@brand.com"
                        aria-invalid={Boolean(state.errors?.email)}
                        aria-describedby={state.errors?.email ? 'email-error' : undefined}
                        className={cn(fieldClass, state.errors?.email && 'border-destructive/60')}
                      />
                      {state.errors?.email ? (
                        <p id="email-error" className="text-xs text-destructive">
                          {state.errors.email}
                        </p>
                      ) : null}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <label htmlFor="service" className="text-sm font-medium">
                      What do you need?
                    </label>
                    <select
                      id="service"
                      name="service"
                      required
                      defaultValue="Both"
                      aria-invalid={Boolean(state.errors?.service)}
                      aria-describedby={state.errors?.service ? 'service-error' : undefined}
                      className={cn(
                        fieldClass,
                        'appearance-none bg-[length:1.1rem] bg-[right_1rem_center] bg-no-repeat pr-10',
                        state.errors?.service && 'border-destructive/60',
                      )}
                      style={{
                        backgroundImage:
                          "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%23a1a1aa' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E\")",
                      }}
                    >
                      <option value="Graphic Design">Graphic Design</option>
                      <option value="Video Editing">Video Editing</option>
                      <option value="Both">Both — design &amp; editing</option>
                      <option value="Not sure yet">Not sure yet</option>
                    </select>
                    {state.errors?.service ? (
                      <p id="service-error" className="text-xs text-destructive">
                        {state.errors.service}
                      </p>
                    ) : null}
                  </div>

                  <div className="flex flex-col gap-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Project details
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={5}
                      maxLength={4000}
                      placeholder="Platform, monthly volume, deadlines, references — anything that helps us scope it."
                      aria-invalid={Boolean(state.errors?.message)}
                      aria-describedby={state.errors?.message ? 'message-error' : undefined}
                      className={cn(
                        fieldClass,
                        'resize-y',
                        state.errors?.message && 'border-destructive/60',
                      )}
                    />
                    {state.errors?.message ? (
                      <p id="message-error" className="text-xs text-destructive">
                        {state.errors.message}
                      </p>
                    ) : null}
                  </div>

                  {state.status === 'error' && state.message ? (
                    <p role="alert" className="text-sm text-destructive">
                      {state.message}
                    </p>
                  ) : null}

                  <button
                    type="submit"
                    disabled={pending}
                    className="group relative mt-1 inline-flex items-center justify-center gap-2 overflow-hidden rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-shadow duration-300 hover:shadow-[0_0_34px_-2px_color-mix(in_oklab,var(--primary)_85%,transparent)] focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-offset-2 focus-visible:ring-offset-background focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-70"
                  >
                    <span className="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent,rgba(255,255,255,0.4),transparent)] transition-transform duration-700 group-hover:translate-x-full" />
                    {pending ? (
                      <>
                        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                        Sending…
                      </>
                    ) : (
                      <>
                        Send Brief
                        <Send className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" />
                      </>
                    )}
                  </button>

                  <p className="text-center text-xs text-muted-foreground">
                    Prefer chatting? Reach us on WhatsApp at {site.whatsappDisplay}.
                  </p>
                </motion.form>
              )}
            </AnimatePresence>
          </SpotlightCard>
        </Reveal>
      </div>
    </section>
  )
}

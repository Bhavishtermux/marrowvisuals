'use client'

import { motion, useScroll, useSpring, useTransform } from 'framer-motion'
import { useRef } from 'react'
import { SectionHeading } from '@/components/section-heading'
import { SpotlightCard } from '@/components/spotlight-card'

type Milestone = {
  year: string
  title: string
  description: string
  points: string[]
}

const milestones: Milestone[] = [
  {
    year: '2025',
    title: 'Full-Service Retainer Studio',
    description:
      'Scaled into a dedicated design and editing team running monthly retainers for creators, coaches and DTC brands across four time zones.',
    points: [
      'Dedicated editor + designer pairs per client',
      'Same-day revision cycles',
      '250+ assets shipped',
    ],
  },
  {
    year: '2024',
    title: 'Short-Form Specialisation',
    description:
      'Doubled down on Reels, Shorts and TikToks. Built a repeatable hook-and-retention framework that became the backbone of every edit we deliver.',
    points: [
      'Retention-first editing framework',
      'Platform-native caption systems',
      'First 7-figure creator accounts',
    ],
  },
  {
    year: 'The Beginning',
    title: 'Two Disciplines, One Studio',
    description:
      'Marrow Visuals started with a single thumbnail commission. We chose to stay narrow — graphic design and video editing only — and go deeper than generalist agencies.',
    points: [
      'First thumbnail & identity clients',
      'Craft over volume from day one',
      'Direct-to-founder communication',
    ],
  },
]

export function Timeline() {
  const containerRef = useRef<HTMLDivElement>(null)

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start 75%', 'end 55%'],
  })

  // smooth the raw progress so the trail glides instead of snapping
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 26, restDelta: 0.001 })
  const height = useTransform(progress, [0, 1], ['0%', '100%'])
  const glowOpacity = useTransform(progress, [0, 0.05, 0.95, 1], [0, 1, 1, 0.9])

  return (
    <section
      aria-labelledby="timeline-heading"
      className="relative mx-auto max-w-5xl px-4 py-24 sm:px-6 lg:py-32"
    >
      <SectionHeading
        eyebrow="Our Journey"
        title={
          <>
            From one commission to a{' '}
            <span className="text-gradient">retainer studio.</span>
          </>
        }
        description="A short history of how Marrow Visuals got sharper by staying narrow."
      />
      <h2 id="timeline-heading" className="sr-only">
        Agency timeline
      </h2>

      <div ref={containerRef} className="relative mt-16 pl-10 sm:pl-16">
        {/* static rail */}
        <div
          aria-hidden="true"
          className="absolute top-2 bottom-2 left-[13px] w-px bg-white/12 sm:left-[29px]"
        />

        {/* animated fill trail */}
        <motion.div
          aria-hidden="true"
          style={{ height, opacity: glowOpacity }}
          className="absolute top-2 left-[13px] w-px origin-top bg-gradient-to-b from-primary via-primary to-transparent shadow-[0_0_16px_3px_color-mix(in_oklab,var(--primary)_70%,transparent)] sm:left-[29px]"
        />

        <ol className="flex flex-col gap-12">
          {milestones.map((milestone, index) => (
            <li key={milestone.year} className="relative">
              {/* node */}
              <motion.span
                aria-hidden="true"
                initial={{ scale: 0, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ duration: 0.45, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="absolute top-6 -left-10 grid size-[27px] place-items-center rounded-full border border-primary/45 bg-background shadow-[0_0_20px_-2px_color-mix(in_oklab,var(--primary)_75%,transparent)] sm:-left-16"
              >
                <span className="size-2.5 rounded-full bg-primary" />
              </motion.span>

              <motion.div
                initial={{ opacity: 0, x: 28 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.7, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
              >
                <SpotlightCard className="p-6 sm:p-7">
                  <p className="font-mono text-xs tracking-[0.2em] text-primary uppercase">
                    {milestone.year}
                  </p>

                  <h3 className="font-display mt-3 text-xl font-bold tracking-tight sm:text-2xl">
                    {milestone.title}
                  </h3>

                  <p className="mt-3 leading-relaxed text-pretty text-muted-foreground">
                    {milestone.description}
                  </p>

                  <ul className="mt-5 flex flex-wrap gap-2">
                    {milestone.points.map((point) => (
                      <li
                        key={point}
                        className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-muted-foreground"
                      >
                        {point}
                      </li>
                    ))}
                  </ul>
                </SpotlightCard>
              </motion.div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}

import { MessagesSquare, Target, TrendingUp, Zap } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { SectionHeading } from '@/components/section-heading'
import { SpotlightCard } from '@/components/spotlight-card'
import { RevealGroup, RevealItem } from '@/components/reveal'

type Feature = {
  icon: LucideIcon
  title: string
  description: string
  metric: string
  metricLabel: string
}

const features: Feature[] = [
  {
    icon: Zap,
    title: 'Fast Turnaround Times',
    description:
      'Most short-form edits and design assets land back with you inside 24 to 48 hours, without the quality drop that usually comes with speed.',
    metric: '24h',
    metricLabel: 'Average delivery',
  },
  {
    icon: Target,
    title: 'Tailored Strategy for Engagement & Retention',
    description:
      'Every edit starts from your audience data — hook structure, pacing and caption rhythm are shaped around what actually keeps your viewers watching.',
    metric: '3.1x',
    metricLabel: 'Avg. watch-time lift',
  },
  {
    icon: TrendingUp,
    title: 'High-Converting Visuals & Retainers',
    description:
      'Thumbnails and creatives built to earn the click, backed by monthly retainers so your output stays consistent instead of sporadic.',
    metric: '98%',
    metricLabel: 'Clients on retainer',
  },
  {
    icon: MessagesSquare,
    title: 'Direct & Seamless Communication',
    description:
      'You talk straight to the people editing and designing your work. One shared thread, clear revision rounds, no account-manager telephone game.',
    metric: '<1h',
    metricLabel: 'Reply time',
  },
]

export function WhyChooseUs() {
  return (
    <section
      id="why-us"
      aria-labelledby="why-us-heading"
      className="relative mx-auto max-w-6xl scroll-mt-28 px-4 py-24 sm:px-6 lg:py-32"
    >
      <SectionHeading
        eyebrow="Why Choose Us"
        title={
          <>
            Built like a partner, <span className="text-gradient">not a vendor.</span>
          </>
        }
        description="The reasons clients stay on retainer after the first delivery — speed, strategy, results, and a direct line to the team doing the work."
      />
      <h2 id="why-us-heading" className="sr-only">
        Why choose us
      </h2>

      <RevealGroup className="mt-14 grid gap-6 sm:grid-cols-2">
        {features.map((feature) => (
          <RevealItem key={feature.title}>
            <SpotlightCard className="flex h-full flex-col p-7">
              <div className="flex items-center gap-4">
                <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-primary/18 ring-1 ring-primary/35">
                  <feature.icon className="size-5 text-primary" aria-hidden="true" />
                </span>
                <div className="ml-auto text-right">
                  <p className="font-display text-2xl font-bold text-foreground">
                    {feature.metric}
                  </p>
                  <p className="text-[0.7rem] tracking-wide text-muted-foreground uppercase">
                    {feature.metricLabel}
                  </p>
                </div>
              </div>

              <h3 className="font-display mt-6 text-xl font-bold tracking-tight text-balance">
                {feature.title}
              </h3>

              <p className="mt-3 leading-relaxed text-pretty text-muted-foreground">
                {feature.description}
              </p>
            </SpotlightCard>
          </RevealItem>
        ))}
      </RevealGroup>
    </section>
  )
}

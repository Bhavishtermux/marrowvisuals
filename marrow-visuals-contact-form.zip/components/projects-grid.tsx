import {
  ArrowLeft,
  ExternalLink,
  Film,
  ImageIcon,
  MessageCircle,
  Play,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { Reveal, RevealGroup, RevealItem } from '@/components/reveal'
import { SpotlightCard } from '@/components/spotlight-card'
import { site, whatsappLink } from '@/lib/site'

type Category = {
  icon: LucideIcon
  title: string
  blurb: string
  image: string
  imageAlt: string
  tags: string[]
  meta: { label: string; value: string }[]
  cta:
    | { kind: 'drive'; label: string; href: string }
    | { kind: 'enquire'; label: string; href: string }
}

const categories: Category[] = [
  {
    icon: Film,
    title: 'Short Form Content',
    blurb:
      'Our flagship library — vertical edits for Instagram Reels, YouTube Shorts and TikTok. Hook-led openings, kinetic captions, beat-matched cuts and sound design tuned for silent-scroll viewing.',
    image: '/images/work-short-form.png',
    imageAlt:
      'Three vertical phone screens showing short-form video edits with bold captions and violet motion graphics',
    tags: ['Reels', 'Shorts', 'TikToks', 'Ad Creatives'],
    meta: [
      { label: 'Format', value: '9:16 Vertical' },
      { label: 'Delivery', value: '24 – 48h' },
      { label: 'Volume', value: '20+ / month' },
    ],
    cta: { kind: 'drive', label: 'View', href: site.portfolioDriveUrl },
  },
  {
    icon: ImageIcon,
    title: 'Graphic Design',
    blurb:
      'Thumbnails engineered for click-through, social post and carousel systems, plus full brand identity kits — logo marks, palettes, type scales and usage rules.',
    image: '/images/work-graphic-design.png',
    imageAlt:
      'Flat-lay collage of thumbnail designs, social posts and a brand identity style sheet in violet and black',
    tags: ['Thumbnails', 'Social Posts', 'Brand Identity'],
    meta: [
      { label: 'Format', value: '16:9 · 1:1 · 4:5' },
      { label: 'Delivery', value: '24h' },
      { label: 'Revisions', value: 'Unlimited' },
    ],
    cta: { kind: 'enquire', label: 'Request Samples', href: whatsappLink },
  },
]

export function ProjectsGrid() {
  return (
    <section
      aria-labelledby="portfolio-heading"
      className="relative mx-auto max-w-6xl px-4 pt-36 pb-24 sm:px-6 sm:pt-44 lg:pb-32"
    >
      <div className="flex flex-col items-center gap-5 text-center">
        <Reveal>
          <Link
            href="/"
            className="group inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="size-4 transition-transform duration-300 group-hover:-translate-x-0.5" />
            Back home
          </Link>
        </Reveal>

        <Reveal delay={0.06}>
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium tracking-[0.18em] text-muted-foreground uppercase">
            <span className="size-1.5 rounded-full bg-primary shadow-[0_0_10px_2px_color-mix(in_oklab,var(--primary)_70%,transparent)]" />
            Portfolio
          </span>
        </Reveal>

        <Reveal delay={0.12}>
          <h1
            id="portfolio-heading"
            className="font-display text-4xl font-bold tracking-tight text-balance sm:text-5xl lg:text-6xl"
          >
            Our <span className="text-gradient">Portfolio &amp; Showcase</span>
          </h1>
        </Reveal>

        <Reveal delay={0.18}>
          <p className="mx-auto max-w-2xl leading-relaxed text-pretty text-muted-foreground">
            Pick a category to preview real deliverables. The short-form library opens in a
            Google Drive folder with the full set of recent edits.
          </p>
        </Reveal>
      </div>

      {/* ---------------- Category cards ---------------- */}
      <RevealGroup className="mt-16 grid gap-6 lg:grid-cols-2" delay={0.1}>
        {categories.map((category) => (
          <RevealItem key={category.title}>
            <SpotlightCard className="flex h-full flex-col">
              <div className="relative aspect-[16/10] overflow-hidden">
                <Image
                  src={category.image}
                  alt={category.imageAlt}
                  fill
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  priority
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />

                {/* play affordance for the video category */}
                {category.cta.kind === 'drive' ? (
                  <span className="absolute inset-0 grid place-items-center">
                    <span className="glass-strong grid size-16 place-items-center rounded-full transition-all duration-500 group-hover:scale-110 group-hover:shadow-[0_0_36px_-4px_color-mix(in_oklab,var(--primary)_80%,transparent)]">
                      <Play className="size-6 translate-x-0.5 fill-foreground text-foreground" aria-hidden="true" />
                    </span>
                  </span>
                ) : null}

                <span className="glass absolute top-4 left-4 inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium">
                  <category.icon className="size-3.5 text-primary" aria-hidden="true" />
                  {category.cta.kind === 'drive' ? 'Video' : 'Design'}
                </span>
              </div>

              <div className="flex flex-1 flex-col p-7 sm:p-8">
                <h2 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">
                  {category.title}
                </h2>

                <p className="mt-3 leading-relaxed text-pretty text-muted-foreground">
                  {category.blurb}
                </p>

                <ul className="mt-6 flex flex-wrap gap-2">
                  {category.tags.map((tag) => (
                    <li
                      key={tag}
                      className="rounded-full border border-primary/25 bg-primary/12 px-3 py-1 text-xs font-medium text-foreground"
                    >
                      {tag}
                    </li>
                  ))}
                </ul>

                <dl className="mt-7 grid grid-cols-3 gap-4 border-t border-white/10 pt-6">
                  {category.meta.map((item) => (
                    <div key={item.label}>
                      <dt className="text-[0.65rem] tracking-[0.14em] text-muted-foreground uppercase">
                        {item.label}
                      </dt>
                      <dd className="mt-1 text-sm font-semibold text-foreground">
                        {item.value}
                      </dd>
                    </div>
                  ))}
                </dl>

                <div className="mt-auto pt-8">
                  <a
                    href={category.cta.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group/btn relative inline-flex w-full items-center justify-center gap-2 overflow-hidden rounded-full bg-primary px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-shadow duration-300 hover:shadow-[0_0_34px_-2px_color-mix(in_oklab,var(--primary)_85%,transparent)] focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-offset-2 focus-visible:ring-offset-background focus-visible:outline-none"
                  >
                    <span className="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent,rgba(255,255,255,0.4),transparent)] transition-transform duration-700 group-hover/btn:translate-x-full" />
                    {category.cta.kind === 'drive' ? (
                      <ExternalLink className="size-4" aria-hidden="true" />
                    ) : (
                      <MessageCircle className="size-4" aria-hidden="true" />
                    )}
                    {category.cta.label}
                    <span className="sr-only">
                      {category.title} — opens in a new tab
                    </span>
                  </a>
                </div>
              </div>
            </SpotlightCard>
          </RevealItem>
        ))}
      </RevealGroup>

      {/* ---------------- Bottom CTA ---------------- */}
      <Reveal className="mt-16" delay={0.1}>
        <SpotlightCard className="flex flex-col items-center gap-6 p-9 text-center sm:p-12" lift={false}>
          <h2 className="font-display max-w-2xl text-2xl font-bold tracking-tight text-balance sm:text-3xl">
            Want something like this for{' '}
            <span className="text-gradient">your brand?</span>
          </h2>
          <p className="max-w-xl leading-relaxed text-pretty text-muted-foreground">
            Send us your channel or handle and we&apos;ll come back with a short teardown plus
            a plan for your first month of content.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-shadow duration-300 hover:shadow-[0_0_30px_-2px_color-mix(in_oklab,var(--primary)_85%,transparent)]"
            >
              <MessageCircle className="size-4" aria-hidden="true" />
              WhatsApp Us
            </a>
            <Link
              href="/#contact"
              className="glass inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-foreground transition-colors duration-300 hover:border-primary/50 hover:bg-white/10"
            >
              Send a Brief
            </Link>
          </div>
        </SpotlightCard>
      </Reveal>
    </section>
  )
}

'use client'

import { motion } from 'framer-motion'
import type { MouseEvent, ReactNode } from 'react'
import { cn } from '@/lib/utils'

/**
 * Glass card with a radial gradient border that follows the cursor,
 * plus a subtle lift + scale on hover.
 */
export function SpotlightCard({
  children,
  className,
  lift = true,
  as = 'div',
}: {
  children: ReactNode
  className?: string
  lift?: boolean
  as?: 'div' | 'li' | 'article'
}) {
  const Comp = motion[as]

  const handleMove = (event: MouseEvent<HTMLElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    event.currentTarget.style.setProperty('--mx', `${event.clientX - rect.left}px`)
    event.currentTarget.style.setProperty('--my', `${event.clientY - rect.top}px`)
  }

  return (
    <Comp
      onMouseMove={handleMove}
      whileHover={lift ? { scale: 1.02, y: -4 } : undefined}
      transition={{ type: 'spring', stiffness: 260, damping: 24 }}
      className={cn(
        'group glass spotlight-border relative overflow-hidden rounded-3xl',
        'transition-colors duration-500 hover:border-primary/40',
        className,
      )}
    >
      {/* inner glow that blooms on hover */}
      <div className="pointer-events-none absolute -inset-px rounded-[inherit] opacity-0 transition-opacity duration-500 group-hover:opacity-100">
        <div className="absolute inset-0 rounded-[inherit] bg-[radial-gradient(320px_circle_at_var(--mx,50%)_var(--my,50%),color-mix(in_oklab,var(--primary)_16%,transparent),transparent_65%)]" />
      </div>

      <div className="relative z-10">{children}</div>
    </Comp>
  )
}

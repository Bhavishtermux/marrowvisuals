'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

/**
 * Seamless infinite ticker. The item list is rendered twice inside a flex track
 * that translates from 0% to -50%, so the loop point is invisible.
 */
export function Marquee({
  items,
  speed = 26,
  reverse = false,
  accent = false,
  className,
}: {
  items: string[]
  /** seconds for one full loop */
  speed?: number
  reverse?: boolean
  accent?: boolean
  className?: string
}) {
  const sequence = [...items, ...items]

  return (
    <div
      aria-hidden="true"
      className={cn(
        'relative flex overflow-hidden border-y border-white/10 py-5 select-none',
        accent
          ? 'bg-primary/12 [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]'
          : 'bg-white/[0.03] [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]',
        className,
      )}
    >
      <motion.div
        className="flex w-max shrink-0 items-center gap-8 pr-8"
        animate={{ x: reverse ? ['-50%', '0%'] : ['0%', '-50%'] }}
        transition={{ duration: speed, ease: 'linear', repeat: Number.POSITIVE_INFINITY }}
      >
        {sequence.map((item, index) => (
          <span key={`${item}-${index}`} className="flex items-center gap-8">
            <span
              className={cn(
                'font-display text-lg font-bold tracking-[0.2em] whitespace-nowrap uppercase sm:text-2xl',
                accent ? 'text-foreground' : 'text-foreground/75',
              )}
            >
              {item}
            </span>
            <span className="text-xl text-primary drop-shadow-[0_0_10px_color-mix(in_oklab,var(--primary)_80%,transparent)] sm:text-2xl">
              {'\u2726'}
            </span>
          </span>
        ))}
      </motion.div>
    </div>
  )
}

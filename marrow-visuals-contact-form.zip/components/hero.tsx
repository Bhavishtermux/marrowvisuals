'use client'

import { motion, useMotionTemplate, useMotionValue, useSpring } from 'framer-motion'
import { ArrowUpRight, Clapperboard, MessageCircle, PenTool, Star } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import type { MouseEvent } from 'react'
import { Typewriter } from '@/components/typewriter'
import { site, stats, whatsappLink } from '@/lib/site'

const EASE = [0.22, 1, 0.36, 1] as const

export function Hero() {
  // --- 3D tilt for the floating profile card -------------------------------
  const rotateX = useSpring(useMotionValue(0), { stiffness: 200, damping: 22 })
  const rotateY = useSpring(useMotionValue(0), { stiffness: 200, damping: 22 })
  const transform = useMotionTemplate`perspective(1100px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`

  const handleTilt = (event: MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    const px = (event.clientX - rect.left) / rect.width - 0.5
    const py = (event.clientY - rect.top) / rect.height - 0.5
    rotateY.set(px * 16)
    rotateX.set(py * -16)
  }

  const resetTilt = () => {
    rotateX.set(0)
    rotateY.set(0)
  }

  return (
    <section
      id="home"
      aria-labelledby="hero-heading"
      className="relative mx-auto flex max-w-6xl flex-col items-center gap-16 px-4 pt-36 pb-20 sm:px-6 sm:pt-44 lg:flex-row lg:items-center lg:gap-12 lg:pt-48 lg:pb-28"
    >
      {/* ---------------- Copy column ---------------- */}
      <div className="flex-1">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE, delay: 0.15 }}
        >
          <span className="glass inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">
            <span className="relative flex size-2">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-accent opacity-75" />
              <span className="relative inline-flex size-2 rounded-full bg-accent" />
            </span>
            Social Media Creative Agency
          </span>
        </motion.div>

        <motion.h1
          id="hero-heading"
          initial={{ opacity: 0, y: 26 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE, delay: 0.25 }}
          className="font-display mt-6 text-4xl leading-[1.05] font-bold tracking-tight text-balance sm:text-5xl lg:text-[3.9rem]"
        >
          Transforming Brands with{' '}
          <span className="text-gradient">High-Impact Graphic Design</span> &amp;{' '}
          <span className="text-gradient">Short-Form Video Editing.</span>
        </motion.h1>

        {/* Typewriter line */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE, delay: 0.4 }}
          className="mt-6 flex items-center gap-3 font-mono text-base sm:text-xl"
        >
          <span className="text-primary">{'>'}</span>
          <Typewriter
            words={['Graphic Design', 'Short-Form Video Editing', 'Content Strategy']}
            className="font-semibold"
          />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE, delay: 0.5 }}
          className="mt-7 max-w-xl leading-relaxed text-pretty text-muted-foreground"
        >
          We build scroll-stopping visuals and retention-engineered edits for creators and
          brands. Two disciplines, done exceptionally well — thumbnails and brand identity
          that get the click, Reels and Shorts that hold the watch time.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE, delay: 0.6 }}
          className="mt-9 flex flex-wrap items-center gap-3"
        >
          <Link
            href="/projects"
            className="group relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-shadow duration-300 hover:shadow-[0_0_34px_-2px_color-mix(in_oklab,var(--primary)_85%,transparent)] focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-offset-2 focus-visible:ring-offset-background focus-visible:outline-none"
          >
            {/* shine sweep */}
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent,rgba(255,255,255,0.45),transparent)] transition-transform duration-700 group-hover:translate-x-full" />
            View Our Work
            <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>

          <Link
            href="/#contact"
            className="glass inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold text-foreground transition-colors duration-300 hover:border-primary/50 hover:bg-white/10 focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
          >
            Start a Project
          </Link>
        </motion.div>

        {/* Stats row */}
        <motion.dl
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: EASE, delay: 0.7 }}
          className="mt-12 grid max-w-lg grid-cols-2 gap-x-6 gap-y-6 sm:grid-cols-4"
        >
          {stats.map((stat) => (
            <div key={stat.label}>
              <dt className="sr-only">{stat.label}</dt>
              <dd className="font-display text-2xl font-bold text-foreground sm:text-3xl">
                {stat.value}
              </dd>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </motion.dl>
      </div>

      {/* ---------------- Floating agency card ---------------- */}
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.9, ease: EASE, delay: 0.35 }}
        className="w-full max-w-sm shrink-0 lg:w-[22rem]"
      >
        {/* continuous hover float */}
        <motion.div
          animate={{ y: [0, -12, 0] }}
          transition={{ duration: 6, ease: 'easeInOut', repeat: Number.POSITIVE_INFINITY }}
        >
          <motion.div
            onMouseMove={handleTilt}
            onMouseLeave={resetTilt}
            style={{ transform, transformStyle: 'preserve-3d' }}
            className="glass-strong relative rounded-[2rem] p-6 shadow-[0_30px_80px_-30px_rgba(0,0,0,0.9)]"
          >
            {/* violet bloom behind the card */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -inset-6 -z-10 rounded-[3rem] bg-primary/22 blur-3xl"
            />

            {/* Availability badge */}
            <div className="flex items-center justify-between">
              <span className="glass inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium text-foreground">
                <span className="relative flex size-2">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-accent opacity-80" />
                  <span className="relative inline-flex size-2 rounded-full bg-accent shadow-[0_0_10px_2px_color-mix(in_oklab,var(--accent)_60%,transparent)]" />
                </span>
                Online / Available for Work
              </span>
            </div>

            {/* Logo + name */}
            <div
              className="mt-6 flex items-center gap-4"
              style={{ transform: 'translateZ(45px)' }}
            >
              <div className="relative size-16 shrink-0 overflow-hidden rounded-2xl ring-1 ring-primary/40">
                <Image
                  src="/images/marrow-mark.png"
                  alt={`${site.name} logo`}
                  fill
                  sizes="64px"
                  className="object-cover"
                  priority
                />
              </div>
              <div>
                <p className="font-display text-lg font-bold tracking-tight">{site.name}</p>
                <p className="text-sm text-muted-foreground">{site.tagline}</p>
              </div>
            </div>

            {/* Rating */}
            <div className="mt-5 flex items-center gap-2" style={{ transform: 'translateZ(30px)' }}>
              <div className="flex gap-0.5" aria-hidden="true">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star key={index} className="size-3.5 fill-primary text-primary" />
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                <span className="sr-only">Rated 5 out of 5. </span>Trusted by 40+ brands
              </p>
            </div>

            {/* Discipline chips */}
            <div
              className="mt-6 grid grid-cols-2 gap-3"
              style={{ transform: 'translateZ(35px)' }}
            >
              <div className="glass rounded-2xl p-3">
                <PenTool className="size-4 text-primary" aria-hidden="true" />
                <p className="mt-2 text-sm font-semibold">Design</p>
                <p className="text-xs text-muted-foreground">Thumbnails &amp; Identity</p>
              </div>
              <div className="glass rounded-2xl p-3">
                <Clapperboard className="size-4 text-primary" aria-hidden="true" />
                <p className="mt-2 text-sm font-semibold">Editing</p>
                <p className="text-xs text-muted-foreground">Reels &amp; Shorts</p>
              </div>
            </div>

            {/* Shiny glass CTA */}
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              style={{ transform: 'translateZ(50px)' }}
              className="group glass relative mt-6 flex w-full items-center justify-center gap-2 overflow-hidden rounded-full px-5 py-3 text-sm font-semibold text-foreground transition-colors duration-300 hover:border-primary/60 hover:bg-primary/20 focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
            >
              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent,rgba(255,255,255,0.28),transparent)] transition-transform duration-700 group-hover:translate-x-full" />
              <MessageCircle className="size-4 text-accent" aria-hidden="true" />
              Message us on WhatsApp
            </a>
          </motion.div>
        </motion.div>
      </motion.div>
    </section>
  )
}

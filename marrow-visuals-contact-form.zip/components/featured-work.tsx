import { ArrowUpRight, ExternalLink } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import { SectionHeading } from '@/components/section-heading'
import { SpotlightCard } from '@/components/spotlight-card'
import { RevealGroup, RevealItem, Reveal } from '@/components/reveal'
import { site } from '@/lib/site'

const featured = [
  {
    title: 'Short Form Content',
    description:
      'Vertical edits for Reels, Shorts and TikToks — hook-led pacing, kinetic captions and sound design built to hold retention to the last frame.',
    image: '/images/work-short-form.png',
    imageAlt:
      'Three vertical phone screens showing short-form video edits with bold captions and violet motion graphics',
    tags: ['Reels', 'Shorts', 'TikToks'],
    href: site.portfolioDriveUrl,
    external: true,
  },
  {
    title: 'Graphic Design Suite',
    description:
      'Thumbnails, carousels and full identity systems — a consistent visual language across every placement your brand shows up in.',
    image: '/images/work-graphic-design.png',
    imageAlt:
      'Flat-lay collage of thumbnail designs, social posts and a brand identity style sheet in violet and black',
    tags: ['Thumbnails', 'Social Posts', 'Identity'],
    href: '/projects',
    external: false,
  },
]

export function FeaturedWork() {
  return (
    <section
      aria-labelledby="featured-heading"
      className="relative mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:py-32"
    >
      <SectionHeading
        eyebrow="Selected Work"
        title={
          <>
            Work that earns the{' '}
            <span className="text-gradient">first three seconds.</span>
          </>
        }
        description="A quick look at what we ship. Open the full showcase for the complete short-form library."
      />
      <h2 id="featured-heading" className="sr-only">
        Featured work
      </h2>

      <RevealGroup className="mt-14 grid gap-6 lg:grid-cols-2">
        {featured.map((project) => (
          <RevealItem key={project.title}>
            <SpotlightCard className="flex h-full flex-col">
              <div className="relative aspect-video overflow-hidden">
                <Image
                  src={project.image}
                  alt={project.imageAlt}
                  fill
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/25 to-transparent" />
              </div>

              <div className="flex flex-1 flex-col p-7">
                <ul className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <li
                      key={tag}
                      className="rounded-full border border-primary/25 bg-primary/12 px-3 py-1 text-xs font-medium text-foreground"
                    >
                      {tag}
                    </li>
                  ))}
                </ul>

                <h3 className="font-display mt-5 text-2xl font-bold tracking-tight">
                  {project.title}
                </h3>

                <p className="mt-3 leading-relaxed text-pretty text-muted-foreground">
                  {project.description}
                </p>

                <div className="mt-7 pt-1">
                  {project.external ? (
                    <a
                      href={project.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/5 px-5 py-2.5 text-sm font-semibold text-foreground transition-colors duration-300 hover:border-primary/50 hover:bg-primary/20 focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
                    >
                      View Showcase
                      <ExternalLink className="size-4" aria-hidden="true" />
                      <span className="sr-only">(opens in a new tab)</span>
                    </a>
                  ) : (
                    <Link
                      href={project.href}
                      className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/5 px-5 py-2.5 text-sm font-semibold text-foreground transition-colors duration-300 hover:border-primary/50 hover:bg-primary/20 focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:outline-none"
                    >
                      Explore Portfolio
                      <ArrowUpRight className="size-4" aria-hidden="true" />
                    </Link>
                  )}
                </div>
              </div>
            </SpotlightCard>
          </RevealItem>
        ))}
      </RevealGroup>

      <Reveal className="mt-12 flex justify-center" delay={0.1}>
        <Link
          href="/projects"
          className="group inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
        >
          See the full portfolio
          <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </Link>
      </Reveal>
    </section>
  )
}

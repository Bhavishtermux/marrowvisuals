'use client'

import { useEffect, useRef } from 'react'

type Blob = {
  /** base position in 0..1 space */
  bx: number
  by: number
  /** orbit radii in 0..1 space */
  ox: number
  oy: number
  /** angular speed + phase */
  speed: number
  phase: number
  /** radius as fraction of the smaller viewport axis */
  radius: number
  color: [number, number, number]
  alpha: number
}

/**
 * Ambient fluid mesh background.
 * Renders slow-orbiting, additively-blended radial gradients on a canvas so the
 * purple haze breathes continuously without any GPU shader dependency.
 */
export function FluidBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d', { alpha: true })
    if (!ctx) return

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    // violet / royal purple / faint indigo — all within one hue family
    const blobs: Blob[] = [
      { bx: 0.24, by: 0.2, ox: 0.1, oy: 0.07, speed: 0.00012, phase: 0.0, radius: 0.72, color: [124, 58, 237], alpha: 0.5 },
      { bx: 0.78, by: 0.28, ox: 0.09, oy: 0.09, speed: 0.00009, phase: 2.1, radius: 0.6, color: [109, 40, 217], alpha: 0.45 },
      { bx: 0.5, by: 0.78, ox: 0.13, oy: 0.06, speed: 0.00015, phase: 4.2, radius: 0.66, color: [91, 33, 182], alpha: 0.4 },
      { bx: 0.12, by: 0.72, ox: 0.07, oy: 0.1, speed: 0.00011, phase: 1.3, radius: 0.5, color: [139, 92, 246], alpha: 0.3 },
      { bx: 0.9, by: 0.86, ox: 0.08, oy: 0.05, speed: 0.00013, phase: 3.4, radius: 0.46, color: [76, 29, 149], alpha: 0.38 },
    ]

    let width = 0
    let height = 0
    let raf = 0
    let dpr = 1

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      width = canvas.clientWidth
      height = canvas.clientHeight
      canvas.width = Math.floor(width * dpr)
      canvas.height = Math.floor(height * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }

    const draw = (t: number) => {
      ctx.clearRect(0, 0, width, height)
      ctx.globalCompositeOperation = 'lighter'

      const min = Math.min(width, height)

      for (const b of blobs) {
        const a = t * b.speed + b.phase
        // two-frequency orbit -> organic, non-circular drift
        const x = (b.bx + Math.cos(a) * b.ox + Math.sin(a * 0.6) * b.ox * 0.35) * width
        const y = (b.by + Math.sin(a) * b.oy + Math.cos(a * 0.75) * b.oy * 0.4) * height

        // gentle breathing scale
        const pulse = 1 + Math.sin(a * 1.4) * 0.12
        const r = b.radius * min * pulse

        const g = ctx.createRadialGradient(x, y, 0, x, y, r)
        const [cr, cg, cb] = b.color
        g.addColorStop(0, `rgba(${cr}, ${cg}, ${cb}, ${b.alpha})`)
        g.addColorStop(0.45, `rgba(${cr}, ${cg}, ${cb}, ${b.alpha * 0.28})`)
        g.addColorStop(1, `rgba(${cr}, ${cg}, ${cb}, 0)`)

        ctx.fillStyle = g
        ctx.beginPath()
        ctx.arc(x, y, r, 0, Math.PI * 2)
        ctx.fill()
      }

      ctx.globalCompositeOperation = 'source-over'
    }

    resize()

    if (reduceMotion) {
      // paint one static frame and stop
      draw(0)
    } else {
      const loop = (now: number) => {
        draw(now)
        raf = requestAnimationFrame(loop)
      }
      raf = requestAnimationFrame(loop)
    }

    const onResize = () => {
      resize()
      if (reduceMotion) draw(0)
    }

    window.addEventListener('resize', onResize)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* base wash so the canvas never sits on pure black */}
      <div className="absolute inset-0 bg-background" />

      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full opacity-70" />

      {/* vignette to pull focus to center content */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_25%,var(--background)_88%)]" />

      {/* faint grid for structure */}
      <div
        className="absolute inset-0 opacity-[0.18]"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(255,255,255,0.055) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.055) 1px, transparent 1px)',
          backgroundSize: '72px 72px',
          maskImage: 'radial-gradient(ellipse at 50% 30%, black 10%, transparent 72%)',
          WebkitMaskImage: 'radial-gradient(ellipse at 50% 30%, black 10%, transparent 72%)',
        }}
      />

      <div className="grain" />
    </div>
  )
}

'use client'

import { useEffect, useRef, useState } from 'react'
import { cn } from '@/lib/utils'

type Phase = 'typing' | 'pausing' | 'deleting'

/**
 * Cycles through `words`, typing and deleting one character at a time.
 * Reserves width with an invisible sizer so surrounding layout never jumps.
 */
export function Typewriter({
  words,
  className,
  typeSpeed = 65,
  deleteSpeed = 32,
  pause = 1600,
}: {
  words: string[]
  className?: string
  typeSpeed?: number
  deleteSpeed?: number
  pause?: number
}) {
  const [index, setIndex] = useState(0)
  const [text, setText] = useState('')
  const [phase, setPhase] = useState<Phase>('typing')
  const reduceMotion = useRef(false)

  useEffect(() => {
    reduceMotion.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduceMotion.current) setText(words[0] ?? '')
  }, [words])

  useEffect(() => {
    if (reduceMotion.current) return
    const word = words[index] ?? ''

    if (phase === 'pausing') {
      const id = setTimeout(() => setPhase('deleting'), pause)
      return () => clearTimeout(id)
    }

    if (phase === 'typing') {
      if (text === word) {
        setPhase('pausing')
        return
      }
      const id = setTimeout(() => setText(word.slice(0, text.length + 1)), typeSpeed)
      return () => clearTimeout(id)
    }

    // deleting
    if (text === '') {
      setIndex((prev) => (prev + 1) % words.length)
      setPhase('typing')
      return
    }
    const id = setTimeout(() => setText(word.slice(0, text.length - 1)), deleteSpeed)
    return () => clearTimeout(id)
  }, [text, phase, index, words, typeSpeed, deleteSpeed, pause])

  const longest = words.reduce((a, b) => (b.length > a.length ? b : a), '')

  return (
    <span className={cn('relative inline-flex items-baseline', className)}>
      {/* invisible sizer prevents layout shift as the text cycles */}
      <span aria-hidden="true" className="pointer-events-none invisible block h-0 overflow-hidden">
        {longest}
      </span>

      <span aria-live="polite" aria-atomic="true" className="absolute inset-0 whitespace-nowrap">
        <span className="text-gradient">{text}</span>
        <span
          aria-hidden="true"
          className="ml-1 inline-block h-[0.95em] w-[3px] translate-y-[0.08em] animate-pulse rounded-full bg-primary align-middle shadow-[0_0_12px_2px_color-mix(in_oklab,var(--primary)_70%,transparent)]"
        />
      </span>
    </span>
  )
}

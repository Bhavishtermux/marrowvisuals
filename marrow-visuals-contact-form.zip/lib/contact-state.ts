export type ContactState = {
  status: 'idle' | 'success' | 'error'
  message: string
  /** Field-level validation messages, keyed by input name. */
  errors?: Partial<Record<'name' | 'email' | 'service' | 'message', string>>
}

export const initialContactState: ContactState = { status: 'idle', message: '' }

export const CONTACT_SERVICES = [
  'Graphic Design',
  'Video Editing',
  'Both',
  'Not sure yet',
] as const

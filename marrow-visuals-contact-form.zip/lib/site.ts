export const site = {
  name: 'Marrow Visuals',
  tagline: 'Graphic Design & Short-Form Video Editing',
  email: 'team.marrowvisuals@zohomail.in',
  /** Raw digits for tel:/wa.me links */
  whatsappDigits: '918107206568',
  whatsappDisplay: '+91 81072 06568',
  portfolioDriveUrl:
    'https://drive.google.com/drive/folders/1nZb4Q6DbYK6Z3JX6U0zD94zc-UHwieUH',
} as const

export const whatsappLink = `https://wa.me/${site.whatsappDigits}?text=${encodeURIComponent(
  "Hi Marrow Visuals! I'd like to discuss a project.",
)}`

export const mailtoLink = `mailto:${site.email}?subject=${encodeURIComponent(
  'Project inquiry — Marrow Visuals',
)}`

export const navLinks = [
  { label: 'Home', href: '/#home' },
  { label: 'Projects', href: '/projects' },
  { label: 'Why Choose Us', href: '/#why-us' },
  { label: 'Contact', href: '/#contact' },
] as const

export const stats = [
  { value: '250+', label: 'Assets Delivered' },
  { value: '40+', label: 'Brands Served' },
  { value: '24h', label: 'Avg. Turnaround' },
  { value: '98%', label: 'Retainer Rate' },
] as const

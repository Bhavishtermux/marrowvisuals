import { Contact } from '@/components/contact'
import { FeaturedWork } from '@/components/featured-work'
import { FluidBackground } from '@/components/fluid-background'
import { Footer } from '@/components/footer'
import { Hero } from '@/components/hero'
import { Marquee } from '@/components/marquee'
import { Navbar } from '@/components/navbar'
import { Services } from '@/components/services'
import { Timeline } from '@/components/timeline'
import { WhyChooseUs } from '@/components/why-choose-us'

export default function HomePage() {
  return (
    <>
      <FluidBackground />
      <Navbar />

      <main>
        <Hero />

        <Marquee
          items={['Graphic Design', 'Short-Form Editing', 'Creative Direction']}
          speed={30}
        />

        <Services />
        <FeaturedWork />
        <WhyChooseUs />
        <Timeline />

        <Marquee
          items={["Reach Out Today!", "Let's Work Together!"]}
          speed={22}
          reverse
          accent
        />

        <Contact />
      </main>

      <Footer />
    </>
  )
}

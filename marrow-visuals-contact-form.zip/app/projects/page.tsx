import type { Metadata } from 'next'
import { FluidBackground } from '@/components/fluid-background'
import { Footer } from '@/components/footer'
import { Marquee } from '@/components/marquee'
import { Navbar } from '@/components/navbar'
import { ProjectsGrid } from '@/components/projects-grid'

export const metadata: Metadata = {
  title: 'Our Portfolio & Showcase',
  description:
    'Browse the Marrow Visuals portfolio — short-form video editing for Reels, Shorts and TikToks, plus thumbnails, social design and brand identity systems.',
}

export default function ProjectsPage() {
  return (
    <>
      <FluidBackground />
      <Navbar />

      <main>
        <ProjectsGrid />

        <Marquee
          items={["Reach Out Today!", "Let's Work Together!"]}
          speed={22}
          reverse
          accent
        />
      </main>

      <Footer />
    </>
  )
}

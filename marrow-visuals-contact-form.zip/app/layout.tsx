import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Syne } from 'next/font/google'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    default: 'Marrow Visuals — Graphic Design & Short-Form Video Editing',
    template: '%s | Marrow Visuals',
  },
  description:
    'Marrow Visuals is a social media agency transforming brands with high-impact graphic design and short-form video editing. Reels, Shorts, TikToks, thumbnails and brand identity built to convert.',
  keywords: [
    'graphic design agency',
    'short form video editing',
    'reels editing',
    'thumbnail design',
    'social media agency',
    'content strategy',
    'brand identity',
  ],
  authors: [{ name: 'Marrow Visuals' }],
  creator: 'Marrow Visuals',
  openGraph: {
    title: 'Marrow Visuals — Graphic Design & Short-Form Video Editing',
    description:
      'High-impact graphic design and short-form video editing for brands that want to stop the scroll.',
    type: 'website',
    siteName: 'Marrow Visuals',
    locale: 'en_US',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Marrow Visuals — Graphic Design & Short-Form Video Editing',
    description:
      'High-impact graphic design and short-form video editing for brands that want to stop the scroll.',
  },
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0b0a10',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`bg-background ${inter.variable} ${syne.variable}`}>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}

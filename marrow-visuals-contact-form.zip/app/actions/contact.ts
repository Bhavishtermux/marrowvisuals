'use server'

import { Resend } from 'resend'

import { CONTACT_SERVICES, type ContactState } from '@/lib/contact-state'
import { site } from '@/lib/site'

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

/** Escape user input before interpolating into the HTML email body. */
function escapeHtml(value: string) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

type Inquiry = { name: string; email: string; service: string; message: string }

async function sendInquiryEmail({ name, email, service, message }: Inquiry) {
  const apiKey = process.env.RESEND_API_KEY

  if (!apiKey) {
    console.error('[v0] RESEND_API_KEY is not set — inquiry was not emailed.')
    return false
  }

  try {
    const resend = new Resend(apiKey)

    const { error } = await resend.emails.send({
      // Resend's shared sender works with no verified domain, but it can only
      // deliver to the Resend account owner's own address. Once you verify a
      // domain in Resend, set CONTACT_FROM_EMAIL (e.g. leads@marrowvisuals.com)
      // and inquiries will send from there with no code change.
      from: `${site.name} Website <${process.env.CONTACT_FROM_EMAIL ?? 'onboarding@resend.dev'}>`,
      to: [site.email],
      replyTo: email,
      subject: `New ${service} inquiry from ${name}`,
      text: [
        `Name: ${name}`,
        `Email: ${email}`,
        `Service: ${service}`,
        '',
        'Message:',
        message,
      ].join('\n'),
      html: `
        <div style="font-family:system-ui,sans-serif;line-height:1.6;color:#111">
          <h2 style="margin:0 0 16px">New ${escapeHtml(service)} inquiry</h2>
          <p style="margin:0 0 4px"><strong>Name:</strong> ${escapeHtml(name)}</p>
          <p style="margin:0 0 4px"><strong>Email:</strong>
            <a href="mailto:${escapeHtml(email)}">${escapeHtml(email)}</a>
          </p>
          <p style="margin:0 0 16px"><strong>Service:</strong> ${escapeHtml(service)}</p>
          <p style="margin:0 0 4px"><strong>Message:</strong></p>
          <p style="margin:0;white-space:pre-wrap">${escapeHtml(message)}</p>
        </div>
      `,
    })

    if (error) {
      console.error('[v0] Resend rejected the inquiry email:', error)
      return false
    }

    return true
  } catch (err) {
    console.error('[v0] Failed to send inquiry email:', err)
    return false
  }
}

export async function submitContact(
  _prevState: ContactState,
  formData: FormData,
): Promise<ContactState> {
  const name = String(formData.get('name') ?? '').trim()
  const email = String(formData.get('email') ?? '').trim()
  const service = String(formData.get('service') ?? '').trim()
  const message = String(formData.get('message') ?? '').trim()

  const errors: ContactState['errors'] = {}

  if (name.length < 2) errors.name = 'Please enter your name.'
  if (name.length > 120) errors.name = 'Name is too long.'

  if (!EMAIL_PATTERN.test(email)) errors.email = 'Please enter a valid email address.'
  if (email.length > 200) errors.email = 'Email is too long.'

  if (!CONTACT_SERVICES.includes(service as (typeof CONTACT_SERVICES)[number])) {
    errors.service = 'Please choose a service.'
  }

  if (message.length < 10) errors.message = 'Tell us a little more (10+ characters).'
  if (message.length > 4000) errors.message = 'Message is too long (4000 characters max).'

  if (Object.keys(errors).length > 0) {
    return {
      status: 'error',
      message: 'Please fix the highlighted fields and try again.',
      errors,
    }
  }

  const delivered = await sendInquiryEmail({ name, email, service, message })

  if (!delivered) {
    // Never leave a real lead stranded: if delivery fails, surface the direct
    // channels instead of a false success so the visitor can still reach us.
    return {
      status: 'error',
      message: `Something went wrong sending your brief. Please WhatsApp us at ${site.whatsappDisplay} or email ${site.email} directly.`,
    }
  }

  return {
    status: 'success',
    message: `Thanks ${name.split(' ')[0]} — your brief landed. We usually reply within an hour.`,
  }
}
